﻿using System;
using System.Collections.Generic;
using System.Text;
using Capa03_AccesoDatos;
using CapaEntidades;


namespace capa02_Logica
{
    internal class Bl_EncabezadoFactura
    {
        private int _id_Factura;
        private DateTime _fecha;
        private int _id_Cliente;
        private decimal _sub_Total;
        private decimal _impuesto;
        private decimal _montoDescuento;

        public int Id_Factura { get => _id_Factura; set => _id_Factura = value; }
        public DateTime Fecha { get => _fecha; set => _fecha = value; }
        public int Id_Cliente { get => _id_Cliente; set => _id_Cliente = value; }

        public Bl_EncabezadoFactura(int id_Factura, DateTime fecha, int id_Cliente, decimal sub_Total, decimal impuesto, decimal montoDescuento)
        {
            _id_Factura = id_Factura;
            _fecha = fecha;
            _id_Cliente = id_Cliente;
            _sub_Total = sub_Total;
            _impuesto = impuesto;
            _montoDescuento = montoDescuento;

        }
    }
}
