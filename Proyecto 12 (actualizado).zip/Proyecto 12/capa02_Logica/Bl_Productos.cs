﻿using System;
using System.Collections.Generic;
using System.Text;
using Capa03_AccesoDatos;
using CapaEntidades;

namespace capa02_Logica
{
    public class Bl_Productos
    {
        //atributos
        private string _cadenaConexion;
        private string _mensaje;

        //propiedades
        public string Mensaje
        {
            get => _mensaje;
        }

        // constructor
        public Bl_Productos(string cadenaConexion)
        {
            _cadenaConexion = cadenaConexion;
            _mensaje = string.Empty;
        }

        //metodo para llamar al metodo insertar de la capa3accesodatos
        public int LlamarMetodoInsertar(Productos producto)
        {
            int id_producto = 0;
            DaProductos accesoDatos = new DaProductos(_cadenaConexion);
            try
            {
                id_producto = accesoDatos.Insertar(producto);
            }
            catch (Exception)
            {
                throw;
            }
            return id_producto;
        }// fin de la clase insertar
    }
}
