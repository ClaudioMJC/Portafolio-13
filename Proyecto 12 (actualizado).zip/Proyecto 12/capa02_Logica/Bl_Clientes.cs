﻿using System;
using System.Collections.Generic;
using System.Text;
using Capa03_AccesoDatos;
using CapaEntidades;

namespace capa02_Logica
{
    public class Bl_Clientes
    {
        //atributos
        private string _cadenaConexion;
        private string _mensaje;

        //propiedades
        public string Mensaje
        {
            get => _mensaje;
        }

        // constructor
        public Bl_Clientes(string cadenaConexion)
        {
            _cadenaConexion = cadenaConexion;
            _mensaje = string.Empty;
        }

        //metodo para llamar al metodo insertar de la capa3accesodatos
        public int LlamarMetodoInsertar(Clientes cliente)
        {
            int id_cliente = 0;
            DACliente accesoDatos = new DACliente(_cadenaConexion);
            try
            {
                id_cliente = accesoDatos.Insertar(cliente);
            }
            catch (Exception)
            {
                throw;
            }
            return id_cliente;
        }// fin de la clase insertar
    }
}
