﻿using System;

namespace CapaEntidades
{
    public class Clientes
    {
        private int id_Cliente;
        private string nombre;
        private string telefono;
        private string direccion;

        //constructores
        public Clientes()
        {
            Id_Cliente = 0;
            Nombre = "";
            Telefono = "";
            Direccion = "";
        }
        public Clientes(int id_Cliente, string nombre, string telefono, string direccion)
        {
            this.Id_Cliente = id_Cliente;
            this.Nombre = nombre;
            this.Telefono = telefono;
    }

        public int Id_Cliente { get => id_Cliente; set => id_Cliente = value; }
        public string Nombre { get => nombre; set => nombre = value; }
        public string Telefono { get => telefono; set => telefono = value; }
        public string Direccion { get => direccion; set => direccion = value; }
        
    }
}
