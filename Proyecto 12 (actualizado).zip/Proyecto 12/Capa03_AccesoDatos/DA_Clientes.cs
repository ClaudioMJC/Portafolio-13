﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Text;
using CapaEntidades;

namespace Capa03_AccesoDatos
{
    public class DACliente
    {       //atributos
        private string _cadenaConexion;
        private string _mensaje;

        //propiedes

        public string Mensaje
        {
            get => _mensaje;
        }

        public DACliente(string cadenaConexion)
        {
            _cadenaConexion = cadenaConexion;
            _mensaje = string.Empty;
        }

        public int Insertar(Clientes cliente)
        {
            int id = 0;
            //Establecer el objeto de conexión
            SqlConnection conexion = new SqlConnection(_cadenaConexion);
            //Establecer el objeto para ejecutar los comandos SQL
            SqlCommand comando = new SqlCommand();
            comando.Connection = conexion;
            string sentencia = "INSERT INTO CLIENTES (NOMBRE, TELEFONO, DIRECCION)" +
                " VALUES( @NOMBRE, @TELEFONO, @DIRECCION) SELECT @@IDENTITY";
            comando.Parameters.AddWithValue("@NOMBRE", cliente.Nombre);
            comando.Parameters.AddWithValue("@TELEFONO", cliente.Telefono);
            comando.Parameters.AddWithValue("DIRECCION", cliente.Direccion);
            comando.CommandText = sentencia;
            try
            {
                conexion.Open();
                id = Convert.ToInt32(comando.ExecuteScalar());
                conexion.Close();
            }
            catch (Exception)
            {
                throw;
            }
            finally
            {
                conexion.Dispose();
                comando.Dispose();
            }
            return id;
        }  //Fin de insertar
    }
}