﻿using System;
using System.Collections.Generic;
using System.Text;
using CapaEntidades;

namespace Capa03_AccesoDatos
{
    internal class DA_Clientes
    {
        private int id_Cliente;
        private string nombre;
        private string telefono;
        private string direccion;

        //constructores
        public DA_Clientes()
        {
            id_Cliente = 0;
            nombre = "";
            telefono = "";
            direccion = "";
        }
        public DA_Clientes(int id_Cliente, string nombre, string telefono, string direccion)
        {
            this.id_Cliente = id_Cliente;
            this.nombre = nombre;
            this.telefono = telefono;
        }
    }
}
