﻿namespace Capas_Practica
{
    partial class FrmProductos
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FrmProductos));
            dataGridView1 = new System.Windows.Forms.DataGridView();
            ID_PRODUCTO = new System.Windows.Forms.DataGridViewTextBoxColumn();
            DESCRIPCION = new System.Windows.Forms.DataGridViewTextBoxColumn();
            PRECIOCOMPRA = new System.Windows.Forms.DataGridViewTextBoxColumn();
            PRECIOVENTA = new System.Windows.Forms.DataGridViewTextBoxColumn();
            GRAVADO = new System.Windows.Forms.DataGridViewTextBoxColumn();
            textGravado = new System.Windows.Forms.TextBox();
            btnBuscar = new System.Windows.Forms.Button();
            btnEliminar = new System.Windows.Forms.Button();
            btnNuevo = new System.Windows.Forms.Button();
            btnGuardar = new System.Windows.Forms.Button();
            btnSalir = new System.Windows.Forms.Button();
            txtPrecioCompra = new System.Windows.Forms.TextBox();
            txtDescripcion = new System.Windows.Forms.TextBox();
            txtPrecioVenta = new System.Windows.Forms.TextBox();
            txtIdCliente = new System.Windows.Forms.TextBox();
            label1 = new System.Windows.Forms.Label();
            label2 = new System.Windows.Forms.Label();
            label3 = new System.Windows.Forms.Label();
            label4 = new System.Windows.Forms.Label();
            label5 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)dataGridView1).BeginInit();
            SuspendLayout();
            // 
            // dataGridView1
            // 
            dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] { ID_PRODUCTO, DESCRIPCION, PRECIOCOMPRA, PRECIOVENTA, GRAVADO });
            dataGridView1.Location = new System.Drawing.Point(27, 109);
            dataGridView1.Name = "dataGridView1";
            dataGridView1.RowHeadersWidth = 62;
            dataGridView1.RowTemplate.Height = 33;
            dataGridView1.Size = new System.Drawing.Size(770, 147);
            dataGridView1.TabIndex = 0;
            // 
            // ID_PRODUCTO
            // 
            ID_PRODUCTO.DataPropertyName = "ID_PRODUCTO)";
            ID_PRODUCTO.HeaderText = "ID_PRODUCTO";
            ID_PRODUCTO.MinimumWidth = 8;
            ID_PRODUCTO.Name = "ID_PRODUCTO";
            ID_PRODUCTO.Width = 150;
            // 
            // DESCRIPCION
            // 
            DESCRIPCION.DataPropertyName = "DESCRIPCION";
            DESCRIPCION.HeaderText = "DESCRIPCIÓN";
            DESCRIPCION.MinimumWidth = 8;
            DESCRIPCION.Name = "DESCRIPCION";
            DESCRIPCION.Width = 150;
            // 
            // PRECIOCOMPRA
            // 
            PRECIOCOMPRA.DataPropertyName = "PRECIOCOMPRA";
            PRECIOCOMPRA.HeaderText = "PRECIOCOMPRA";
            PRECIOCOMPRA.MinimumWidth = 8;
            PRECIOCOMPRA.Name = "PRECIOCOMPRA";
            PRECIOCOMPRA.Width = 150;
            // 
            // PRECIOVENTA
            // 
            PRECIOVENTA.HeaderText = "PRECIOVENTA";
            PRECIOVENTA.MinimumWidth = 8;
            PRECIOVENTA.Name = "PRECIOVENTA";
            PRECIOVENTA.Width = 150;
            // 
            // GRAVADO
            // 
            GRAVADO.HeaderText = "GRAVADO";
            GRAVADO.MinimumWidth = 8;
            GRAVADO.Name = "GRAVADO";
            GRAVADO.Width = 150;
            // 
            // textGravado
            // 
            textGravado.Location = new System.Drawing.Point(678, 44);
            textGravado.Name = "textGravado";
            textGravado.Size = new System.Drawing.Size(165, 31);
            textGravado.TabIndex = 52;
            // 
            // btnBuscar
            // 
            btnBuscar.Image = (System.Drawing.Image)resources.GetObject("btnBuscar.Image");
            btnBuscar.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            btnBuscar.Location = new System.Drawing.Point(27, 296);
            btnBuscar.Name = "btnBuscar";
            btnBuscar.Size = new System.Drawing.Size(111, 110);
            btnBuscar.TabIndex = 51;
            btnBuscar.Text = "&Buscar";
            btnBuscar.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            btnBuscar.UseVisualStyleBackColor = true;
            // 
            // btnEliminar
            // 
            btnEliminar.Image = (System.Drawing.Image)resources.GetObject("btnEliminar.Image");
            btnEliminar.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            btnEliminar.Location = new System.Drawing.Point(157, 296);
            btnEliminar.Name = "btnEliminar";
            btnEliminar.Size = new System.Drawing.Size(111, 110);
            btnEliminar.TabIndex = 50;
            btnEliminar.Text = "Eliminar";
            btnEliminar.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            btnEliminar.UseVisualStyleBackColor = true;
            // 
            // btnNuevo
            // 
            btnNuevo.Image = (System.Drawing.Image)resources.GetObject("btnNuevo.Image");
            btnNuevo.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            btnNuevo.Location = new System.Drawing.Point(445, 296);
            btnNuevo.Name = "btnNuevo";
            btnNuevo.Size = new System.Drawing.Size(111, 110);
            btnNuevo.TabIndex = 49;
            btnNuevo.Text = "&Nuevo";
            btnNuevo.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            btnNuevo.UseVisualStyleBackColor = true;
            // 
            // btnGuardar
            // 
            btnGuardar.Image = (System.Drawing.Image)resources.GetObject("btnGuardar.Image");
            btnGuardar.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            btnGuardar.Location = new System.Drawing.Point(301, 296);
            btnGuardar.Name = "btnGuardar";
            btnGuardar.Size = new System.Drawing.Size(111, 110);
            btnGuardar.TabIndex = 48;
            btnGuardar.Text = "&Guardar";
            btnGuardar.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            btnGuardar.UseVisualStyleBackColor = true;
            btnGuardar.Click += btnGuardar_Click;
            // 
            // btnSalir
            // 
            btnSalir.Image = (System.Drawing.Image)resources.GetObject("btnSalir.Image");
            btnSalir.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            btnSalir.Location = new System.Drawing.Point(601, 296);
            btnSalir.Name = "btnSalir";
            btnSalir.Size = new System.Drawing.Size(111, 110);
            btnSalir.TabIndex = 47;
            btnSalir.Text = "&Salir";
            btnSalir.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            btnSalir.UseVisualStyleBackColor = true;
            btnSalir.Click += btnSalir_Click;
            // 
            // txtPrecioCompra
            // 
            txtPrecioCompra.Location = new System.Drawing.Point(308, 44);
            txtPrecioCompra.Multiline = true;
            txtPrecioCompra.Name = "txtPrecioCompra";
            txtPrecioCompra.Size = new System.Drawing.Size(158, 32);
            txtPrecioCompra.TabIndex = 46;
            // 
            // txtDescripcion
            // 
            txtDescripcion.Location = new System.Drawing.Point(157, 45);
            txtDescripcion.Name = "txtDescripcion";
            txtDescripcion.Size = new System.Drawing.Size(145, 31);
            txtDescripcion.TabIndex = 45;
            // 
            // txtPrecioVenta
            // 
            txtPrecioVenta.Location = new System.Drawing.Point(498, 44);
            txtPrecioVenta.Name = "txtPrecioVenta";
            txtPrecioVenta.Size = new System.Drawing.Size(165, 31);
            txtPrecioVenta.TabIndex = 44;
            // 
            // txtIdCliente
            // 
            txtIdCliente.BackColor = System.Drawing.SystemColors.Info;
            txtIdCliente.Location = new System.Drawing.Point(4, 45);
            txtIdCliente.Name = "txtIdCliente";
            txtIdCliente.ReadOnly = true;
            txtIdCliente.Size = new System.Drawing.Size(125, 31);
            txtIdCliente.TabIndex = 43;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new System.Drawing.Point(12, 9);
            label1.Name = "label1";
            label1.Size = new System.Drawing.Size(130, 25);
            label1.TabIndex = 53;
            label1.Text = "ID_PRODUCTO";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new System.Drawing.Point(725, 9);
            label2.Name = "label2";
            label2.Size = new System.Drawing.Size(95, 25);
            label2.TabIndex = 54;
            label2.Text = "GRAVADO";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new System.Drawing.Point(517, 9);
            label3.Name = "label3";
            label3.Size = new System.Drawing.Size(125, 25);
            label3.TabIndex = 55;
            label3.Text = "PRECIOVENTA";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new System.Drawing.Point(308, 9);
            label4.Name = "label4";
            label4.Size = new System.Drawing.Size(146, 25);
            label4.TabIndex = 56;
            label4.Text = "PRECIOCOMPRA";
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Location = new System.Drawing.Point(166, 9);
            label5.Name = "label5";
            label5.Size = new System.Drawing.Size(124, 25);
            label5.TabIndex = 57;
            label5.Text = "DESCRIPCION";
            // 
            // FrmProductos
            // 
            AutoScaleDimensions = new System.Drawing.SizeF(10F, 25F);
            AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            ClientSize = new System.Drawing.Size(851, 450);
            Controls.Add(label5);
            Controls.Add(label4);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(label1);
            Controls.Add(textGravado);
            Controls.Add(btnBuscar);
            Controls.Add(btnEliminar);
            Controls.Add(btnNuevo);
            Controls.Add(btnGuardar);
            Controls.Add(btnSalir);
            Controls.Add(txtPrecioCompra);
            Controls.Add(txtDescripcion);
            Controls.Add(txtPrecioVenta);
            Controls.Add(txtIdCliente);
            Controls.Add(dataGridView1);
            Name = "FrmProductos";
            Text = "FrmProductos";
            ((System.ComponentModel.ISupportInitialize)dataGridView1).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.DataGridViewTextBoxColumn ID_PRODUCTO;
        private System.Windows.Forms.DataGridViewTextBoxColumn DESCRIPCION;
        private System.Windows.Forms.DataGridViewTextBoxColumn PRECIOCOMPRA;
        private System.Windows.Forms.DataGridViewTextBoxColumn PRECIOVENTA;
        private System.Windows.Forms.DataGridViewTextBoxColumn GRAVADO;
        private System.Windows.Forms.TextBox textGravado;
        private System.Windows.Forms.Button btnBuscar;
        private System.Windows.Forms.Button btnEliminar;
        private System.Windows.Forms.Button btnNuevo;
        private System.Windows.Forms.Button btnGuardar;
        private System.Windows.Forms.Button btnSalir;
        private System.Windows.Forms.TextBox txtPrecioCompra;
        private System.Windows.Forms.TextBox txtDescripcion;
        private System.Windows.Forms.TextBox txtPrecioVenta;
        private System.Windows.Forms.TextBox txtIdCliente;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
    }
}